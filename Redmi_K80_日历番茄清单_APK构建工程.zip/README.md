# 时光序 · 日历番茄清单 (Redmi K80至尊版) APK 构建指南

由于云端安全沙箱未内置 Android SDK 编译链，本工程已为您配置好完整的 **Android 原生 WebView 工程** 及 **免配环境云端自动打包脚本**。您可以通过以下任意一种方式在 1~3 分钟内获得 `.apk` 安装包：

## 方法一：使用在线一键转换工具（最快，无需电脑配置，1 分钟生成 APK）
1. 打开免费在线 HTML 转 APK 工具 **[WebIntoApp](https://www.webintoapp.com/html-to-app)** 或 **[AppsGeyser](https://appsgeyser.com/)**。
2. 上传本压缩包内的 `app/src/main/assets/index.html`（或直接上传附带的增强版 HTML 文件）。
3. 图标选择压缩包内的 `app/src/main/res/mipmap-xxxhdpi/ic_launcher.png`，应用名称填写 `时光序·番茄日历`，点击 **Make App** 即可直接下载 `.apk` 安装包到手机安装。

## 方法二：使用 GitHub Actions 免本地环境自动打包 APK
1. 在 GitHub 新建一个仓库，将本压缩包解压后的全部文件上传到仓库中。
2. 点击仓库顶部的 **Actions** 标签页，系统会自动运行内置的 `.github/workflows/build-apk.yml` 工作流。
3. 等待约 1~2 分钟构建完成后，在构建页面底部的 **Artifacts** 区域点击 `Redmi-K80-Focus-Calendar-APK` 即可下载签名好的 `.apk` 安装包。

## 方法三：使用 Android Studio 本地打包
1. 使用 Android Studio 打开解压后的工程文件夹。
2. 等待 Gradle 同步完成后，点击顶部菜单 **Build -> Build Bundle(s) / APK(s) -> Build APK(s)**。
3. 在 `app/build/outputs/apk/` 目录下即可获取生成的 `.apk` 文件。
